import matplotlib.pyplot as plt

# === Datos simulados ===
# Escenario 1: Carga/Descarga
usuarios_carga = [10, 50, 100, 200, 300]
tiempos_carga = [800, 1200, 1800, 2500, 3200]  # ms
throughput_carga = [20, 80, 150, 230, 280]     # videos/min

# Escenario 2: Reproducción
usuarios_playback = [20, 100, 250, 500]
tiempos_playback = [500, 800, 1200, 1600]      # ms
concurrentes_ok = [20, 100, 230, 450]          # usuarios sin buffering

# === Gráfico 1: Tiempo de respuesta vs usuarios (Carga/Descarga) ===
plt.figure(figsize=(7,5))
plt.plot(usuarios_carga, tiempos_carga, marker="o")
plt.axhline(3000, color="r", linestyle="--", label="Límite aceptación 3000 ms")
plt.title("Escenario 1: Tiempo de Respuesta vs Usuarios (Carga/Descarga)")
plt.xlabel("Usuarios concurrentes")
plt.ylabel("Tiempo de respuesta (ms)")
plt.legend()
plt.grid(True)
plt.savefig("grafico_tiempo_carga.png")

# === Gráfico 2: Throughput vs usuarios (Carga/Descarga) ===
plt.figure(figsize=(7,5))
plt.plot(usuarios_carga, throughput_carga, marker="s", color="green")
plt.axhline(50, color="r", linestyle="--", label="Criterio mínimo 50/min")
plt.title("Escenario 1: Throughput vs Usuarios (Carga/Descarga)")
plt.xlabel("Usuarios concurrentes")
plt.ylabel("Throughput (videos/min)")
plt.legend()
plt.grid(True)
plt.savefig("grafico_throughput_carga.png")

# === Gráfico 3: Tiempo de inicio reproducción vs usuarios ===
plt.figure(figsize=(7,5))
plt.plot(usuarios_playback, tiempos_playback, marker="^", color="purple")
plt.axhline(1500, color="r", linestyle="--", label="Límite aceptación 1500 ms")
plt.title("Escenario 2: Tiempo de Inicio Reproducción vs Usuarios")
plt.xlabel("Usuarios concurrentes")
plt.ylabel("Tiempo inicio (ms)")
plt.legend()
plt.grid(True)
plt.savefig("grafico_tiempo_playback.png")

# === Gráfico 4: Sesiones concurrentes sin buffering ===
plt.figure(figsize=(7,5))
plt.plot(usuarios_playback, concurrentes_ok, marker="d", color="orange")
plt.axhline(200, color="r", linestyle="--", label="Criterio mínimo 200 usuarios sin buffering")
plt.title("Escenario 2: Sesiones Concurrentes sin Buffering")
plt.xlabel("Usuarios concurrentes")
plt.ylabel("Usuarios reproducidos sin buffering")
plt.legend()
plt.grid(True)
plt.savefig("grafico_buffering_playback.png")

print("✅ Gráficas generadas: grafico_tiempo_carga.png, grafico_throughput_carga.png, grafico_tiempo_playback.png, grafico_buffering_playback.png")
