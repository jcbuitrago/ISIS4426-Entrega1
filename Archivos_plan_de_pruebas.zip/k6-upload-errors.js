import http from 'k6/http';
import { check, sleep } from 'k6';
import { Trend } from 'k6/metrics';
import { randomSeed } from 'k6';

// Error scenarios: wrong resolution, wrong format, duplicate name

const BASE_URL = __ENV.BASE_URL || 'http://localhost:8080';
const TOKEN = __ENV.TOKEN || '';
const TIMEOUT_MS = Number(__ENV.TIMEOUT_MS || 60000);

const headers = {
  'Authorization': TOKEN ? `Bearer ${TOKEN}` : '',
};

// dummy files
const validFile = open('./video_100mb.bin', 'b');
const wrongFormatFile = open('./fake.txt', 'b'); // you need to create a dummy fake.txt

export const options = {
  scenarios: {
    wrong_resolution: {
      executor: 'constant-vus',
      vus: 20,
      duration: '2m',
      exec: 'testWrongResolution',
    },
    wrong_format: {
      executor: 'constant-vus',
      vus: 20,
      duration: '2m',
      exec: 'testWrongFormat',
    },
    duplicate_name: {
      executor: 'ramping-vus',
      startVUs: 0,
      stages: [
        { duration: '1m', target: 50 },
        { duration: '1m', target: 100 },
        { duration: '1m', target: 0 },
      ],
      gracefulRampDown: '30s',
      exec: 'testDuplicateName',
    },
  },
  thresholds: {
    'checks{scenario:wrong_resolution}': ['rate>0.95'],
    'checks{scenario:wrong_format}': ['rate>0.95'],
    'checks{scenario:duplicate_name}': ['rate>0.95'],
  },
};

// wrong resolution (simulate as .mp4 but expected to fail by backend rules)
export function testWrongResolution() {
  const formData = {
    file: http.file(validFile, 'video_4k.mp4', 'video/mp4'),
  };
  const res = http.post(`${BASE_URL}/api/videos/upload`, formData, {
    headers,
    tags: { type: 'wrong-resolution' },
    timeout: `${TIMEOUT_MS}ms`,
  });
  check(res, {
    'reject wrong resolution': (r) => r.status === 400 || r.status === 422,
  });
  sleep(1);
}

// wrong format (non-video file)
export function testWrongFormat() {
  const formData = {
    file: http.file(wrongFormatFile, 'fake.txt', 'text/plain'),
  };
  const res = http.post(`${BASE_URL}/api/videos/upload`, formData, {
    headers,
    tags: { type: 'wrong-format' },
    timeout: `${TIMEOUT_MS}ms`,
  });
  check(res, {
    'reject wrong format': (r) => r.status === 415,
  });
  sleep(1);
}

// duplicate names (send same filename concurrently)
export function testDuplicateName() {
  const formData = {
    file: http.file(validFile, 'video_dup.mp4', 'video/mp4'),
  };
  const res = http.post(`${BASE_URL}/api/videos/upload`, formData, {
    headers,
    tags: { type: 'duplicate-name' },
    timeout: `${TIMEOUT_MS}ms`,
  });
  check(res, {
    'reject or rename duplicates': (r) => r.status === 409 || r.status === 200,
  });
  sleep(1);
}
